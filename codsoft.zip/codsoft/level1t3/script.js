let displayValue = '';

function appendToDisplay(value) {
    document.getElementById('display').value +=value ;
}

function clearDisplay() {
    document.getElementById('display').value = '';
}

function calculate() {
    try {
        displayValue = eval(displayValue);
        document.getElementById('display').value = displayValue;
    } catch (error) {
        document.getElementById('display').value = 'Error';
    }
}
